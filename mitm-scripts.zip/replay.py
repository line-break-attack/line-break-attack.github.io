from mitmproxy import http

def request(flow: http.HTTPFlow) -> None:
    if (
        flow.request.method == "POST" and
        flow.request.pretty_url == "https://legy-backup.line-apps.com/ECA5" and
        flow.request.content
    ):
        body = bytearray(flow.request.content)

        index_to_modify = 2
        if len(body) > index_to_modify:
            original = body[index_to_modify]
            body[index_to_modify] = 0xFF
            flow.request.content = bytes(body)  # Set the content properly
            print(f"Modified byte at index {index_to_modify} from {original} to 0xFF")

    if (
        flow.request.method == "POST" and
        flow.request.pretty_url == "https://legy-de.aws.line-apps.com/ECA5" and
        flow.request.content
    ):
        body = bytearray(flow.request.content)

        index_to_modify = 2
        if len(body) > index_to_modify:
            original = body[index_to_modify]
            body[index_to_modify] = 0xFF
            flow.request.content = bytes(body)  # Set the content properly
            print(f"Modified byte at index {index_to_modify} from {original} to 0xFF")