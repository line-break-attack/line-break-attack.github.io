from mitmproxy import ctx, http

class ModifyAndReplay:
    def __init__(self):
        self.replayed = False

    def load(self, loader):
        loader.add_option(
            name="modify_byte_index",
            typespec=int,
            default=77,
            help="Index of the byte to modify in the request body."
        )
    
    def request(self, flow:http.HTTPFlow):
        if self.replayed: 
            return
        
        if flow.request.method == "POST" and flow.request.raw_content:
            body = bytearray(flow.request.raw_content)
            index_to_modify = ctx.options.modify_byte_index
            
            if len(body) > index_to_modify:
                original = body[index_to_modify]
                body[index_to_modify] = 0x00
                flow.request.raw_content = bytes(body)
                print(f"Modified byte at index {index_to_modify} from {original} to 0x00")
                
                # Set the flag to prevent further modifications
                ctx.master.commands.call("replay.client", [flow])
                self.replayed = True