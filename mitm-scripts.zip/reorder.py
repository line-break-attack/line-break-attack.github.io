from mitmproxy import http

def response(flow: http.HTTPFlow) -> None:
    if (
        flow.request.method == "POST" and
        flow.request.pretty_url == "https://legy-de.aws.line-apps.com/ECA5" and
        flow.response.content
    ):
        print("hello")
        body = bytearray(flow.response.content)
        index_to_modify = 1
    
        if len(body) > index_to_modify:
            original = body[index_to_modify]

            if original == 0xbc:
                print("Original byte at index 1 is 0xbc, modifying to 0xbe")
                body[index_to_modify] = 0xbe
            if original == 0xbe:
                print("Original byte at index 1 is 0xbe, modifying to 0xbc")
                body[index_to_modify] = 0xbc
            flow.response.content = bytes(body)  # Set the content properly
            print(f"Modified byte at index {index_to_modify} from {original} to {body[index_to_modify]}")

    if (
    flow.request.method == "POST" and
    flow.request.pretty_url == "https://legy-backup.line-apps.com/ECA5" and
    flow.response.content
    ):
        print("hello")
        body = bytearray(flow.response.content)
        index_to_modify = 1
    
        if len(body) > index_to_modify:
            original = body[index_to_modify]

            if original == 0xbc:
                print("Original byte at index 1 is 0xbc, modifying to 0xbe")
                body[index_to_modify] = 0xbe
            if original == 0xbe:
                print("Original byte at index 1 is 0xbe, modifying to 0xbc")
                body[index_to_modify] = 0xbc
            flow.response.content = bytes(body)  # Set the content properly
            print(f"Modified byte at index {index_to_modify} from {original} to {body[index_to_modify]}")