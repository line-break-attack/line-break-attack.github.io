from mitmproxy import http
import re

old_stuff__ = 565194451086737582
new_stuff__ = 565195531975655425
REPLACEMENT = 565199999999999999
big = 565199999999999999

pattern = re.compile(r"5651\d+")

def relace(text):
    return pattern.sub(str(REPLACEMENT), text)

def request(flow: http.HTTPFlow) -> None:
    if (
        flow.request.method == "POST" and
        flow.request.pretty_url == "https://legy-backup.line-apps.com/S4" and
        flow.request.raw_content
    ):
        try:
            text = flow.request.get_text()
            modified_text = relace(text)
            flow.request.set_text(modified_text)
        except Exception as e:
            print(f"Error modifying request text: {e}")

    if (
        flow.request.method == "POST" and
        flow.request.pretty_url == "https://legy-de.aws.line-apps.com/S4" and
        flow.request.raw_content
    ):
        try:
            text = flow.request.get_text()
            modified_text = relace(text)
            flow.request.set_text(modified_text)
        except Exception as e:
            print(f"Error modifying request text: {e}")