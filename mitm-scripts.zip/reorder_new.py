from mitmproxy import http
from mitmproxy import ctx

# Storage for the two flows
flows_to_swap = []

def response(flow: http.HTTPFlow) -> None:
    if (
        flow.request.method == "POST"
        and flow.request.host == "legy-de.aws.line-apps.com"
        and flow.request.path == "/ECA5"
        and "content-encoding" not in flow.response.headers
        and len(flow.response.content) >= 18
    ):
        # Append the flow for later modification
        flows_to_swap.append(flow)

        if len(flows_to_swap) == 2:
            # Extract timestamps
            flow1 = flows_to_swap[0]
            flow2 = flows_to_swap[1]

            body1 = bytearray(flow1.response.content)
            body2 = bytearray(flow2.response.content)

            ts1 = body1
            ts2 = body2

            # Swap timestamps
            body1 = ts2
            body2 = ts1

            # Apply changes
            flow1.response.content = bytes(body1)
            flow2.response.content = bytes(body2)

            ctx.log.info(f"Swapped timestamps: {int.from_bytes(ts1, 'little')} <=> {int.from_bytes(ts2, 'little')}")

            # Clear the list so it doesn't keep swapping every two
            flows_to_swap.clear()
